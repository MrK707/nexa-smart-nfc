import React, { useState } from 'react';
import { 
  UserPen, 
  Building2, 
  Phone, 
  Share2, 
  Save, 
  Check, 
  ArrowLeft, 
  Camera, 
  Plus, 
  Trash2, 
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { useCustomer } from '../context/CustomerContext';
import { UserProfile } from '../types';

export const EditProfilePage: React.FC = () => {
  const { profile, updateProfile, navigate, completion } = useCustomer();
  
  // Local state initialized with current profile
  const [formData, setFormData] = useState<UserProfile>(profile);
  const [activeTab, setActiveTab] = useState<'personal' | 'business' | 'contact' | 'social'>('personal');
  const [isSaved, setIsSaved] = useState(false);
  const [newService, setNewService] = useState('');

  const handlePersonalChange = (field: keyof UserProfile['personal'], value: string) => {
    setFormData(prev => ({
      ...prev,
      personal: {
        ...prev.personal,
        [field]: value,
      },
    }));
  };

  const handleBusinessChange = (field: keyof UserProfile['business'], value: any) => {
    setFormData(prev => ({
      ...prev,
      business: {
        ...prev.business,
        [field]: value,
      },
    }));
  };

  const handleContactChange = (field: keyof UserProfile['contact'], value: string) => {
    setFormData(prev => ({
      ...prev,
      contact: {
        ...prev.contact,
        [field]: value,
      },
    }));
  };

  const handleSocialChange = (field: keyof UserProfile['social'], value: string) => {
    setFormData(prev => ({
      ...prev,
      social: {
        ...prev.social,
        [field]: value,
      },
    }));
  };

  const handleAddService = () => {
    if (!newService.trim()) return;
    setFormData(prev => ({
      ...prev,
      business: {
        ...prev.business,
        services: [...(prev.business.services || []), newService.trim()],
      },
    }));
    setNewService('');
  };

  const handleRemoveService = (index: number) => {
    setFormData(prev => ({
      ...prev,
      business: {
        ...prev.business,
        services: prev.business.services.filter((_, i) => i !== index),
      },
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300">
        {/* Top Breadcrumb & Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.06]">
          <div>
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-purple-300 transition-colors mb-2 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </button>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>Edit Digital Profile</span>
              <span className="text-xs px-2.5 py-1 rounded-full bg-purple-950/60 text-purple-300 border border-purple-500/20 font-medium">
                Live Sync
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              Changes reflect immediately on your dashboard, smart NFC business card, and public link.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(`/u/${formData.personal.username}`)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium text-zinc-300 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] hover:border-purple-500/30 transition-all cursor-pointer"
            >
              <span>View Public</span>
              <ExternalLink className="w-3.5 h-3.5 text-purple-400" />
            </button>

            <button
              id="edit-profile-save-top-btn"
              onClick={handleSubmit}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium text-sm text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-900/30 hover:shadow-purple-900/50 transition-all cursor-pointer"
            >
              {isSaved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{isSaved ? 'Saved to Card!' : 'Save Changes'}</span>
            </button>
          </div>
        </div>

        {/* Tab Selection Navigation */}
        <div className="flex items-center gap-2 p-1.5 bg-[#121118] border border-white/[0.08] rounded-2xl overflow-x-auto">
          {[
            { id: 'personal', label: 'Personal Info', icon: UserPen },
            { id: 'business', label: 'Business & Bio', icon: Building2 },
            { id: 'contact', label: 'Contact Details', icon: Phone },
            { id: 'social', label: 'Social Networks', icon: Share2 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isTabActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  isTabActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* TAB 1: Personal Info */}
          {activeTab === 'personal' && (
            <div className="rounded-2xl p-6 sm:p-8 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-6">
              <h3 className="text-base font-bold text-white tracking-tight pb-3 border-b border-white/[0.06]">
                Personal Identity
              </h3>

              {/* Profile Photo URL & Quick Presets */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Profile Photo URL
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="relative w-20 h-20 rounded-2xl p-[2px] bg-gradient-to-tr from-purple-500 to-indigo-500 shrink-0">
                    <img
                      src={formData.personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                      alt="Preview"
                      className="w-full h-full rounded-[14px] object-cover bg-zinc-900"
                    />
                  </div>
                  <div className="flex-1 w-full space-y-2">
                    <input
                      type="url"
                      id="input-profile-photo"
                      value={formData.personal.profile_photo}
                      onChange={(e) => handlePersonalChange('profile_photo', e.target.value)}
                      placeholder="https://example.com/avatar.jpg"
                      className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white placeholder-zinc-600 transition-colors"
                    />
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[11px] text-zinc-500">Quick Avatars:</span>
                      {[
                        { label: 'Executive 1', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80' },
                        { label: 'Executive 2', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80' },
                        { label: 'Executive 3', url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80' },
                      ].map((preset) => (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => handlePersonalChange('profile_photo', preset.url)}
                          className="px-2 py-1 rounded-md text-[11px] font-medium bg-white/[0.04] hover:bg-white/[0.08] text-purple-300 border border-white/[0.06] transition-colors cursor-pointer"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Full Name & Job Title */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="input-full-name"
                    value={formData.personal.full_name}
                    onChange={(e) => handlePersonalChange('full_name', e.target.value)}
                    placeholder="e.g. John Perera"
                    required
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    Job Title / Designation
                  </label>
                  <input
                    type="text"
                    id="input-job-title"
                    value={formData.personal.job_title}
                    onChange={(e) => handlePersonalChange('job_title', e.target.value)}
                    placeholder="e.g. Founder & CEO"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white transition-colors"
                  />
                </div>
              </div>

              {/* Username Handle */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Card Handle / Username (used in NFC public URL)
                </label>
                <div className="flex items-center rounded-xl bg-white/[0.04] border border-white/[0.08] focus-within:border-purple-500 px-3 py-1 transition-colors">
                  <span className="text-xs text-zinc-500 font-mono">tap.nexacreatives.site/u/</span>
                  <input
                    type="text"
                    id="input-username"
                    value={formData.personal.username}
                    onChange={(e) => handlePersonalChange('username', e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                    placeholder="username"
                    required
                    className="flex-1 px-1 py-1.5 bg-transparent border-none focus:outline-hidden text-sm text-purple-300 font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Business & Bio */}
          {activeTab === 'business' && (
            <div className="rounded-2xl p-6 sm:p-8 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-6">
              <h3 className="text-base font-bold text-white tracking-tight pb-3 border-b border-white/[0.06]">
                Business Profile
              </h3>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Company / Brand Name
                </label>
                <input
                  type="text"
                  id="input-company-name"
                  value={formData.business.company_name}
                  onChange={(e) => handleBusinessChange('company_name', e.target.value)}
                  placeholder="e.g. Nexa Solutions"
                  className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Executive Bio / About
                </label>
                <textarea
                  id="input-bio"
                  rows={4}
                  value={formData.business.bio}
                  onChange={(e) => handleBusinessChange('bio', e.target.value)}
                  placeholder="Share a short summary of what you or your business does..."
                  className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white transition-colors leading-relaxed"
                />
              </div>

              {/* Services Tags */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Services / Core Competencies
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newService}
                    onChange={(e) => setNewService(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddService();
                      }
                    }}
                    placeholder="Add service (e.g. NFC Digital Identity) and press enter"
                    className="flex-1 px-4 py-2 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddService}
                    className="px-4 py-2 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 text-xs font-semibold border border-purple-500/30 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-2 pt-2">
                  {formData.business.services?.map((svc, i) => (
                    <span
                      key={i}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium bg-white/[0.05] border border-white/[0.08] text-purple-300"
                    >
                      <span>{svc}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveService(i)}
                        className="text-zinc-500 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Contact Info */}
          {activeTab === 'contact' && (
            <div className="rounded-2xl p-6 sm:p-8 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-6">
              <h3 className="text-base font-bold text-white tracking-tight pb-3 border-b border-white/[0.06]">
                Direct Contact Points
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    id="input-phone"
                    value={formData.contact.phone}
                    onChange={(e) => handleContactChange('phone', e.target.value)}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    WhatsApp Number
                  </label>
                  <input
                    type="text"
                    id="input-whatsapp"
                    value={formData.contact.whatsapp}
                    onChange={(e) => handleContactChange('whatsapp', e.target.value)}
                    placeholder="+15550000000 (with country code)"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="input-email"
                    value={formData.contact.email}
                    onChange={(e) => handleContactChange('email', e.target.value)}
                    placeholder="john@example.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    Website URL
                  </label>
                  <input
                    type="url"
                    id="input-website"
                    value={formData.contact.website}
                    onChange={(e) => handleContactChange('website', e.target.value)}
                    placeholder="https://example.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Business Location / Address
                </label>
                <input
                  type="text"
                  id="input-address"
                  value={formData.contact.address}
                  onChange={(e) => handleContactChange('address', e.target.value)}
                  placeholder="City, State, Country"
                  className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white"
                />
              </div>
            </div>
          )}

          {/* TAB 4: Social Links */}
          {activeTab === 'social' && (
            <div className="rounded-2xl p-6 sm:p-8 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-6">
              <h3 className="text-base font-bold text-white tracking-tight pb-3 border-b border-white/[0.06]">
                Social & Network Handles
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    LinkedIn Username / Path
                  </label>
                  <div className="flex items-center rounded-xl bg-white/[0.04] border border-white/[0.08] px-3 py-1">
                    <span className="text-xs text-zinc-500 font-mono">linkedin.com/in/</span>
                    <input
                      type="text"
                      id="input-linkedin"
                      value={formData.social.linkedin}
                      onChange={(e) => handleSocialChange('linkedin', e.target.value)}
                      placeholder="johnperera"
                      className="flex-1 px-1 py-1.5 bg-transparent border-none focus:outline-hidden text-sm text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    Instagram Handle
                  </label>
                  <div className="flex items-center rounded-xl bg-white/[0.04] border border-white/[0.08] px-3 py-1">
                    <span className="text-xs text-zinc-500 font-mono">@</span>
                    <input
                      type="text"
                      id="input-instagram"
                      value={formData.social.instagram}
                      onChange={(e) => handleSocialChange('instagram', e.target.value)}
                      placeholder="john.nexa"
                      className="flex-1 px-1 py-1.5 bg-transparent border-none focus:outline-hidden text-sm text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    Facebook Handle
                  </label>
                  <input
                    type="text"
                    id="input-facebook"
                    value={formData.social.facebook}
                    onChange={(e) => handleSocialChange('facebook', e.target.value)}
                    placeholder="johnperera.official"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] focus:border-purple-500 focus:outline-hidden text-sm text-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400">
                    TikTok Handle
                  </label>
                  <div className="flex items-center rounded-xl bg-white/[0.04] border border-white/[0.08] px-3 py-1">
                    <span className="text-xs text-zinc-500 font-mono">@</span>
                    <input
                      type="text"
                      id="input-tiktok"
                      value={formData.social.tiktok}
                      onChange={(e) => handleSocialChange('tiktok', e.target.value)}
                      placeholder="john_perera"
                      className="flex-1 px-1 py-1.5 bg-transparent border-none focus:outline-hidden text-sm text-white"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Bottom Save Action Bar */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-[#121118] border border-white/[0.08]">
            <div className="flex items-center gap-2 text-xs text-zinc-400">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Smart NFC chip syncs automatically when saved.</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                id="edit-profile-save-bottom-btn"
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-medium text-sm text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-900/30 transition-all cursor-pointer"
              >
                {isSaved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
                <span>{isSaved ? 'Saved!' : 'Save Changes'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
};
