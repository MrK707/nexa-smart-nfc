import React, { useState } from 'react';
import { 
  Settings, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  Bell, 
  User, 
  LogOut, 
  Check, 
  Radio, 
  Smartphone,
  Eye,
  EyeOff,
  Download
} from 'lucide-react';
import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { useCustomer } from '../context/CustomerContext';

export const SettingsPage: React.FC = () => {
  const { profile, updateProfile, session, logout, recordCustomActivity } = useCustomer();
  const { card } = profile;

  const isCardActive = card.card_status === 'active';
  const [showSavedFeedback, setShowSavedFeedback] = useState(false);
  const [hidePhoneOnPublic, setHidePhoneOnPublic] = useState(false);
  const [allowInstantVcard, setAllowInstantVcard] = useState(true);

  const toggleCardLock = () => {
    const nextStatus = isCardActive ? 'locked' : 'active';
    updateProfile({
      card: {
        ...card,
        card_status: nextStatus,
      },
    });
    recordCustomActivity(
      nextStatus === 'locked' ? 'card_locked' : 'profile_updated',
      nextStatus === 'locked' ? 'NFC Card locked by user' : 'NFC Card unlocked & active',
      'Hardware lock state updated'
    );
    setShowSavedFeedback(true);
    setTimeout(() => setShowSavedFeedback(false), 3000);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300 max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.06]">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>Account & Hardware Settings</span>
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              Control smart card hardware pairing, privacy preferences, and authentication security.
            </p>
          </div>

          {showSavedFeedback && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <Check className="w-3.5 h-3.5" />
              <span>Preferences saved</span>
            </div>
          )}
        </div>

        {/* Section 1: Smart Card Hardware Security (Lock/Unlock) */}
        <div className="rounded-2xl p-6 sm:p-7 bg-[#121118]/85 backdrop-blur-xl border border-white/[0.08] space-y-4">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-purple-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              Smart NFC Card Security
            </h3>
          </div>
          <p className="text-xs text-zinc-400">
            If you ever misplace your physical card, instantly lock it here to prevent anyone from tapping it.
          </p>

          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/[0.06] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3">
              <div className={`p-2.5 rounded-xl border shrink-0 ${
                isCardActive 
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                  : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
              }`}>
                {isCardActive ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
              </div>
              <div>
                <p className="text-sm font-bold text-white">
                  Card Broadcasting Status: {isCardActive ? 'Active & Discoverable' : 'Locked & Silent'}
                </p>
                <p className="text-xs text-zinc-400 mt-0.5">
                  UID: <span className="font-mono text-purple-300">{card.nfc_uid || '04:A2:8F:2B:6C:91'}</span>
                </p>
              </div>
            </div>

            <button
              id="settings-toggle-card-lock-btn"
              onClick={toggleCardLock}
              className={`inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isCardActive
                  ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30'
                  : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30'
              }`}
            >
              {isCardActive ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              <span>{isCardActive ? 'Lock Smart Card' : 'Unlock Smart Card'}</span>
            </button>
          </div>
        </div>

        {/* Section 2: Privacy Controls */}
        <div className="rounded-2xl p-6 sm:p-7 bg-[#121118]/85 backdrop-blur-xl border border-white/[0.08] space-y-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              Privacy & Tap Permissions
            </h3>
          </div>

          <div className="divide-y divide-white/[0.05]">
            <div className="py-3.5 flex items-center justify-between gap-4">
              <div>
                <p className="text-xs sm:text-sm font-semibold text-white">Allow 1-Tap Direct vCard Download</p>
                <p className="text-[11px] sm:text-xs text-zinc-400 mt-0.5">
                  Allows viewers of your public card to add you to their iPhone/Android contacts with one click.
                </p>
              </div>
              <input
                type="checkbox"
                checked={allowInstantVcard}
                onChange={(e) => setAllowInstantVcard(e.target.checked)}
                className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
              />
            </div>

            <div className="py-3.5 flex items-center justify-between gap-4">
              <div>
                <p className="text-xs sm:text-sm font-semibold text-white">Hide Phone Number on Public Web Profile</p>
                <p className="text-[11px] sm:text-xs text-zinc-400 mt-0.5">
                  Only show email and WhatsApp to public viewers.
                </p>
              </div>
              <input
                type="checkbox"
                checked={hidePhoneOnPublic}
                onChange={(e) => setHidePhoneOnPublic(e.target.checked)}
                className="w-4 h-4 accent-purple-600 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Session & Account Information */}
        <div className="rounded-2xl p-6 sm:p-7 bg-[#121118]/85 backdrop-blur-xl border border-white/[0.08] space-y-4">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-indigo-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              Authenticated Session
            </h3>
          </div>

          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-zinc-400">Logged in as:</p>
              <p className="text-sm font-bold text-white mt-0.5">{session.user?.email || 'john@nexacreatives.com'}</p>
              <span className="inline-block mt-1 text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-purple-950/60 border border-purple-500/20 text-purple-300">
                Role: {session.user?.role || 'customer'}
              </span>
            </div>

            <button
              id="settings-logout-btn"
              onClick={logout}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-rose-300 hover:text-white bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Log out</span>
            </button>
          </div>
        </div>

        {/* Section 4: Export Source Code & Assets */}
        <div className="rounded-2xl p-6 sm:p-7 bg-[#121118]/85 backdrop-blur-xl border border-purple-500/20 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Download className="w-4 h-4 text-purple-400" />
              <h3 className="text-base font-bold text-white tracking-tight">
                Export Project Source Code
              </h3>
            </div>
            <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/30">
              ZIP Package
            </span>
          </div>

          <p className="text-xs text-zinc-400">
            Download the complete production-ready source code bundle of the Nexa Creatives Smart NFC Dashboard, components, design system, and pages.
          </p>

          <div className="pt-2">
            <a
              id="settings-download-source-zip-btn"
              href="/nexa-dashboard-source.zip"
              download="nexa-dashboard-source.zip"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-900/30 hover:shadow-purple-900/50 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download nexa-dashboard-source.zip (91 KB)</span>
            </a>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};
