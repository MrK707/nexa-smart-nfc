import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { 
  Share2, 
  Copy, 
  Check, 
  Download, 
  MessageSquare, 
  Mail, 
  Smartphone, 
  ExternalLink,
  QrCode,
  Sparkles,
  Printer
} from 'lucide-react';
import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { useCustomer } from '../context/CustomerContext';

export const SharePage: React.FC = () => {
  const { profile, recordCustomActivity, navigate } = useCustomer();
  const { personal, business } = profile;

  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const [shareStatus, setShareStatus] = useState<string | null>(null);

  const publicUrl = `https://tap.nexacreatives.site/u/${personal.username}`;

  useEffect(() => {
    QRCode.toDataURL(publicUrl, {
      width: 400,
      margin: 2,
      color: {
        dark: '#0c0b11',
        light: '#ffffff',
      },
    })
      .then(url => setQrDataUrl(url))
      .catch(err => console.error(err));
  }, [publicUrl]);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(publicUrl);
      setCopied(true);
      recordCustomActivity('link_shared', 'Public profile link copied to clipboard', publicUrl);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${personal.full_name} | Nexa Smart NFC Card`,
          text: `Here is the digital business card for ${personal.full_name} (${personal.job_title}):`,
          url: publicUrl,
        });
        recordCustomActivity('link_shared', 'Shared card using System Share', publicUrl);
      } catch (err) {
        console.log('Share dismissed', err);
      }
    } else {
      handleCopyLink();
      setShareStatus('Link copied to clipboard!');
      setTimeout(() => setShareStatus(null), 3000);
    }
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello! Connect with me on my Nexa Smart NFC digital business card:\n${personal.full_name} - ${personal.job_title}\n${publicUrl}`
    );
    recordCustomActivity('link_shared', 'Shared card via WhatsApp', publicUrl);
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  const handleEmailShare = () => {
    const subject = encodeURIComponent(`${personal.full_name} - Digital Business Card`);
    const body = encodeURIComponent(
      `Hi,\n\nPlease find my Nexa Smart NFC business card below:\n${personal.full_name}\n${personal.job_title} | ${business.company_name}\n\nView my card and save contact details: ${publicUrl}\n`
    );
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  const handleDownloadQr = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `${personal.username || 'nexa'}-qr.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    recordCustomActivity('qr_scanned', 'Downloaded QR Code asset');
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300 max-w-5xl mx-auto">
        {/* Page Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.06]">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>Share My Smart Card</span>
              <span className="text-xs px-2.5 py-1 rounded-full bg-purple-950/60 text-purple-300 border border-purple-500/20 font-medium">
                Multi-Channel
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              Share your digital business identity via QR code, direct link, WhatsApp, or instant NFC.
            </p>
          </div>

          <button
            onClick={() => navigate(`/u/${personal.username}`)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-zinc-200 bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.08] hover:border-purple-500/30 transition-all cursor-pointer self-start sm:self-auto"
          >
            <span>Preview Public Card</span>
            <ExternalLink className="w-4 h-4 text-purple-400" />
          </button>
        </div>

        {/* 2-Column Sharing Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: High-Res QR Card Display */}
          <div className="lg:col-span-5 flex flex-col items-center rounded-3xl p-8 bg-[#121118]/85 backdrop-blur-xl border border-white/[0.08] shadow-2xl text-center">
            <div className="p-4 bg-white rounded-2xl shadow-xl shadow-black/60 mb-6">
              {qrDataUrl ? (
                <img 
                  src={qrDataUrl} 
                  alt="QR Code" 
                  className="w-56 h-56 sm:w-64 sm:h-64 object-contain"
                />
              ) : (
                <div className="w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center text-zinc-500 text-xs">
                  Generating High-Res QR...
                </div>
              )}
            </div>

            <h3 className="text-base font-bold text-white tracking-tight">
              Scan to Connect Instantly
            </h3>
            <p className="text-xs text-zinc-400 mt-1 max-w-xs">
              Directly opens your NFC profile on any iOS or Android camera without installing any apps.
            </p>

            <button
              onClick={handleDownloadQr}
              className="mt-6 w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-purple-600 hover:bg-purple-500 shadow-lg shadow-purple-950 transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Printable QR Image</span>
            </button>
          </div>

          {/* Right: Sharing Channels & Instant Actions */}
          <div className="lg:col-span-7 space-y-6">
            {/* Share Link Box */}
            <div className="rounded-2xl p-6 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-3">
              <label className="block text-xs font-semibold uppercase tracking-wider text-purple-400">
                Direct Public Card URL
              </label>

              <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.08] flex items-center justify-between gap-3">
                <span className="text-xs sm:text-sm font-mono text-zinc-200 truncate">
                  {publicUrl}
                </span>

                <button
                  id="share-page-copy-btn"
                  onClick={handleCopyLink}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-purple-600 hover:bg-purple-500 shadow-md transition-all cursor-pointer shrink-0"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Link</span>
                    </>
                  )}
                </button>
              </div>

              {shareStatus && (
                <p className="text-xs text-emerald-400 font-medium">{shareStatus}</p>
              )}
            </div>

            {/* Sharing Methods Grid */}
            <div className="rounded-2xl p-6 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-4">
              <h3 className="text-sm font-bold text-white tracking-tight">
                Quick Sharing Channels
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={handleNativeShare}
                  className="flex items-center gap-3 p-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] hover:border-purple-500/30 text-left transition-all cursor-pointer group"
                >
                  <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20 group-hover:scale-105 transition-transform">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white group-hover:text-purple-200">
                      System Native Share
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">AirDrop, SMS, Nearby</p>
                  </div>
                </button>

                <button
                  onClick={handleWhatsApp}
                  className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/5 hover:bg-emerald-500/10 border border-emerald-500/20 hover:border-emerald-500/30 text-left transition-all cursor-pointer group"
                >
                  <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 group-hover:scale-105 transition-transform">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white group-hover:text-emerald-200">
                      Send to WhatsApp
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">Direct chat message</p>
                  </div>
                </button>

                <button
                  onClick={handleEmailShare}
                  className="flex items-center gap-3 p-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] hover:border-purple-500/30 text-left transition-all cursor-pointer group"
                >
                  <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 group-hover:scale-105 transition-transform">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white group-hover:text-indigo-200">
                      Email Card
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">Pre-composed email link</p>
                  </div>
                </button>

                <button
                  onClick={handleDownloadQr}
                  className="flex items-center gap-3 p-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] hover:border-purple-500/30 text-left transition-all cursor-pointer group"
                >
                  <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 group-hover:scale-105 transition-transform">
                    <Printer className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white group-hover:text-blue-200">
                      Print Badge / Card
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">Vector QR format</p>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};
