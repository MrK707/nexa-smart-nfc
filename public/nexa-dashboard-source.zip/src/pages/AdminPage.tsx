import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  Radio, 
  Activity, 
  Search, 
  ArrowLeft, 
  LogOut, 
  CheckCircle2, 
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { useCustomer } from '../context/CustomerContext';

export const AdminPage: React.FC = () => {
  const { session, logout, navigate, profile } = useCustomer();
  const [searchQuery, setSearchQuery] = useState('');

  const registeredCards = [
    {
      id: 'CARD-9021',
      owner: profile.personal.full_name,
      username: profile.personal.username,
      uid: profile.card.nfc_uid || '04:A2:8F:2B:6C:91',
      status: profile.card.card_status,
      issued: '2026-01-15',
      taps: 142,
    },
    {
      id: 'CARD-8812',
      owner: 'Elena Rostova',
      username: 'elena_r',
      uid: '04:C8:11:9A:34:F1',
      status: 'active',
      issued: '2026-02-02',
      taps: 389,
    },
    {
      id: 'CARD-7643',
      owner: 'Marcus Vance',
      username: 'mvance',
      uid: '04:77:E3:42:09:88',
      status: 'locked',
      issued: '2026-02-19',
      taps: 85,
    },
  ];

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 p-4 sm:p-8 antialiased">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Admin Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Nexa Fleet Administrator
                </h1>
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  Role: Admin
                </span>
              </div>
              <p className="text-xs sm:text-sm text-zinc-400 mt-1">
                Global NFC Smart Card Provisioning, Mesh Security & Tenant Diagnostics.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-zinc-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Switch to Customer Dashboard</span>
            </button>

            <button
              onClick={logout}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-rose-300 hover:text-white bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Global Hardware Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-[#121118]/80 border border-white/[0.08]">
            <span className="text-xs text-zinc-400 font-medium">Provisioned NFC Cards</span>
            <p className="text-2xl font-bold text-white mt-1">1,248</p>
            <span className="text-[11px] text-emerald-400 mt-1 inline-block">● 99.4% Operational</span>
          </div>

          <div className="p-5 rounded-2xl bg-[#121118]/80 border border-white/[0.08]">
            <span className="text-xs text-zinc-400 font-medium">Monthly Tap Interactions</span>
            <p className="text-2xl font-bold text-purple-300 mt-1">48,920</p>
            <span className="text-[11px] text-zinc-500 mt-1 inline-block">Real NFC handshakes</span>
          </div>

          <div className="p-5 rounded-2xl bg-[#121118]/80 border border-white/[0.08]">
            <span className="text-xs text-zinc-400 font-medium">Active Tenants</span>
            <p className="text-2xl font-bold text-indigo-300 mt-1">842</p>
            <span className="text-[11px] text-purple-400 mt-1 inline-block">Corporate + Pro</span>
          </div>

          <div className="p-5 rounded-2xl bg-[#121118]/80 border border-white/[0.08]">
            <span className="text-xs text-zinc-400 font-medium">Crypto Mesh Integrity</span>
            <p className="text-2xl font-bold text-emerald-400 mt-1">100%</p>
            <span className="text-[11px] text-zinc-500 mt-1 inline-block">Zero revoked keys</span>
          </div>
        </div>

        {/* Card Management Table */}
        <div className="rounded-2xl p-6 bg-[#121118]/80 border border-white/[0.08] space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.06]">
            <div>
              <h3 className="text-base font-bold text-white">NFC Hardware Registry</h3>
              <p className="text-xs text-zinc-400">View real-time status of client smart cards.</p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
                <input
                  type="text"
                  placeholder="Search card ID, owner..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-xs text-white placeholder-zinc-500 focus:outline-hidden focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/[0.06] text-zinc-500 uppercase tracking-wider font-mono text-[10px]">
                  <th className="pb-3 font-semibold">Card ID</th>
                  <th className="pb-3 font-semibold">Cardholder</th>
                  <th className="pb-3 font-semibold">NFC Chip UID</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 font-semibold">Issued Date</th>
                  <th className="pb-3 font-semibold text-right">Taps</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04] font-medium">
                {registeredCards.map((card) => (
                  <tr key={card.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3 font-mono text-zinc-300">{card.id}</td>
                    <td className="py-3 text-white">
                      <div>
                        <span>{card.owner}</span>
                        <span className="text-[10px] text-zinc-500 block">@{card.username}</span>
                      </div>
                    </td>
                    <td className="py-3 font-mono text-purple-300">{card.uid}</td>
                    <td className="py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        card.status === 'active' 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}>
                        <span className={`w-1 h-1 rounded-full ${card.status === 'active' ? 'bg-emerald-400' : 'bg-rose-400'}`}></span>
                        {card.status}
                      </span>
                    </td>
                    <td className="py-3 text-zinc-400">{card.issued}</td>
                    <td className="py-3 text-right font-mono text-zinc-300">{card.taps}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
