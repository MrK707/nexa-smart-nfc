import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { 
  Radio, 
  RotateCw, 
  Download, 
  Share2, 
  ExternalLink, 
  ShieldCheck, 
  Sparkles, 
  Smartphone,
  Check,
  Zap
} from 'lucide-react';
import { DashboardLayout } from '../components/dashboard/DashboardLayout';
import { useCustomer } from '../context/CustomerContext';
import { downloadVCard } from '../lib/vcard';

export const DigitalCardPage: React.FC = () => {
  const { profile, navigate, setShareModalOpen, recordCustomActivity } = useCustomer();
  const { personal, business, contact, card } = profile;

  const [isFlipped, setIsFlipped] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState('obsidian-purple');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [isNfcTapping, setIsNfcTapping] = useState(false);
  const [nfcSuccess, setNfcSuccess] = useState(false);

  const publicUrl = `https://tap.nexacreatives.site/u/${personal.username}`;

  useEffect(() => {
    QRCode.toDataURL(publicUrl, {
      width: 240,
      margin: 1,
      color: {
        dark: '#ffffff',
        light: '#00000000',
      },
    })
      .then(url => setQrCodeUrl(url))
      .catch(err => console.error(err));
  }, [publicUrl]);

  const themes = [
    {
      id: 'aurora-glass',
      label: 'Aurora Glass (Light)',
      gradient: 'from-[#ffffff] via-[#f3f1fb] to-[#e0e7ff]',
      border: 'border-[#7c3aed]/30',
      accent: 'text-[#7c3aed]',
      accentBg: 'bg-gradient-to-r from-[#7c3aed] to-[#22d3ee]',
    },
    {
      id: 'obsidian-purple',
      label: 'Obsidian Purple',
      gradient: 'from-[#1a1429] via-[#0f0c18] to-[#07060a]',
      border: 'border-purple-500/30',
      accent: 'text-purple-400',
      accentBg: 'bg-purple-600',
    },
    {
      id: 'titanium-noir',
      label: 'Titanium Noir',
      gradient: 'from-[#1e1e24] via-[#121216] to-[#08080a]',
      border: 'border-zinc-500/30',
      accent: 'text-zinc-300',
      accentBg: 'bg-zinc-700',
    },
    {
      id: 'aurora-violet',
      label: 'Aurora Violet',
      gradient: 'from-[#2e1065] via-[#1e113a] to-[#0a0614]',
      border: 'border-indigo-400/40',
      accent: 'text-indigo-300',
      accentBg: 'bg-indigo-600',
    },
    {
      id: 'cyber-emerald',
      label: 'Cyber Emerald',
      gradient: 'from-[#062c26] via-[#091b18] to-[#040d0c]',
      border: 'border-emerald-500/30',
      accent: 'text-emerald-400',
      accentBg: 'bg-emerald-600',
    },
  ];

  const currentThemeObj = themes.find(t => t.id === selectedTheme) || themes[0];

  const handleDownloadContact = () => {
    downloadVCard(profile);
    recordCustomActivity('vcard_saved', 'Downloaded vCard contact file', `${personal.full_name}.vcf`);
  };

  const handleSimulateNfcTap = () => {
    setIsNfcTapping(true);
    setNfcSuccess(false);

    setTimeout(() => {
      setIsNfcTapping(false);
      setNfcSuccess(true);
      recordCustomActivity('card_viewed', 'NFC Hardware Tap simulated', 'Transmitted NTAG424 DNA signature');
      setTimeout(() => setNfcSuccess(false), 4000);
    }, 1200);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.06]">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>My Smart NFC Digital Card</span>
              <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-950/60 text-emerald-400 border border-emerald-500/20 font-medium">
                Hardware Paired
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              Interactive 3D preview of the card paired with your physical NFC chip.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShareModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-zinc-200 bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.08] hover:border-purple-500/30 transition-all cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-purple-400" />
              <span>Share Card</span>
            </button>

            <button
              onClick={handleDownloadContact}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs sm:text-sm text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-900/30 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Save vCard (.vcf)</span>
            </button>
          </div>
        </div>

        {/* Card Stage / Viewer */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Card Presentation Area */}
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col items-center justify-center p-6 sm:p-12 rounded-3xl bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] relative overflow-hidden min-h-[460px]">
            {/* Ambient Background lighting */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

            {/* Tap simulation ripple effect */}
            {isNfcTapping && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
                <span className="animate-ping absolute w-48 h-48 rounded-full bg-purple-500/30" />
                <span className="animate-ping delay-150 absolute w-72 h-72 rounded-full bg-indigo-500/20" />
                <div className="p-4 rounded-2xl bg-black/80 backdrop-blur-md border border-purple-500/50 text-purple-300 text-xs font-mono flex items-center gap-2 shadow-2xl">
                  <Radio className="w-4 h-4 animate-spin text-purple-400" />
                  <span>Scanning NFC chip signature...</span>
                </div>
              </div>
            )}

            {nfcSuccess && (
              <div className="absolute top-6 left-1/2 -translate-x-1/2 z-20 px-4 py-2 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-semibold flex items-center gap-2 shadow-xl animate-in fade-in duration-200">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>NFC Handshake Successful! Contact broadcast ready.</span>
              </div>
            )}

            {/* The 3D NFC Card Container */}
            <div className="relative w-full max-w-[420px] aspect-[1.586/1] perspective-1000 group">
              <div 
                className={`relative w-full h-full rounded-2xl sm:rounded-3xl p-6 sm:p-7 bg-gradient-to-br ${currentThemeObj.gradient} border ${currentThemeObj.border} shadow-2xl shadow-black/80 transition-all duration-700 transform-style-3d cursor-pointer ${
                  isFlipped ? 'rotate-y-180' : ''
                }`}
                onClick={() => setIsFlipped(prev => !prev)}
                title="Click card to flip"
              >
                {/* FRONT FACE */}
                <div className={`absolute inset-0 p-6 sm:p-7 flex flex-col justify-between backface-hidden ${isFlipped ? 'hidden' : 'flex'}`}>
                  {/* Top header row */}
                  <div className="flex items-center justify-between">
                    {/* Metallic Smart NFC Chip Icon */}
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-7 rounded-md bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 p-[1px] shadow-sm">
                        <div className="w-full h-full bg-[#1b1926] rounded-[5px] flex items-center justify-center">
                          <div className="w-5 h-3 border border-amber-300/40 rounded-[2px]" />
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-75">
                        <Radio className="w-4 h-4 text-purple-400" />
                        <span className="text-[10px] font-mono tracking-widest text-purple-300 uppercase">
                          NFC
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-right">
                      <span className="text-xs font-extrabold tracking-wider text-white">NEXA</span>
                      <span className="text-[9px] font-bold text-purple-400 uppercase bg-purple-950/60 px-1 py-0.5 rounded border border-purple-500/20">
                        CREATIVES
                      </span>
                    </div>
                  </div>

                  {/* Middle User Info */}
                  <div className="flex items-center gap-4 my-auto">
                    <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl p-[1.5px] bg-gradient-to-tr from-purple-400 to-indigo-400 shrink-0">
                      <img
                        src={personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                        alt={personal.full_name}
                        className="w-full h-full rounded-[14px] object-cover bg-zinc-900"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight truncate">
                        {personal.full_name}
                      </h3>
                      <p className="text-xs font-semibold text-purple-300 truncate">
                        {personal.job_title}
                      </p>
                      <p className="text-[11px] text-zinc-400 truncate">
                        {business.company_name}
                      </p>
                    </div>
                  </div>

                  {/* Bottom Footer Row */}
                  <div className="flex items-end justify-between pt-2 border-t border-white/[0.08]">
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase font-mono block">
                        Chip Identification
                      </span>
                      <span className="text-xs font-mono text-zinc-300">
                        {card.nfc_uid || '04:A2:8F:2B:6C:91'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-purple-300 font-mono">
                      <span>TAP TO CONNECT</span>
                    </div>
                  </div>
                </div>

                {/* BACK FACE */}
                <div className={`absolute inset-0 p-6 sm:p-7 flex flex-col justify-between backface-hidden [transform:rotateY(180deg)] ${isFlipped ? 'flex' : 'hidden'}`}>
                  {/* Magnetic Strip Illusion */}
                  <div className="-mx-6 sm:-mx-7 -mt-6 sm:-mt-7 h-10 bg-black/90 border-b border-white/[0.05]" />

                  {/* QR & Tap Instructions */}
                  <div className="flex items-center justify-between gap-4 py-2">
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-mono text-purple-400 tracking-wider">
                        Scan or Tap
                      </span>
                      <h4 className="text-sm font-bold text-white">
                        Digital Profile Link
                      </h4>
                      <p className="text-[11px] font-mono text-zinc-400 truncate max-w-[200px]">
                        tap.nexacreatives.site/u/{personal.username}
                      </p>
                    </div>

                    {qrCodeUrl && (
                      <div className="p-2 rounded-xl bg-white/[0.06] border border-white/10 shrink-0">
                        <img src={qrCodeUrl} alt="QR" className="w-16 h-16 object-contain" />
                      </div>
                    )}
                  </div>

                  {/* Card Security Signature */}
                  <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between text-[10px] font-mono text-zinc-500">
                    <span>NEXA SMART ID • CRYPTO VERIFIED</span>
                    <span>FLIP BACK ↺</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Card Controls Bar */}
            <div className="flex flex-wrap items-center gap-3 mt-8">
              <button
                id="card-flip-btn"
                onClick={() => setIsFlipped(prev => !prev)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-zinc-200 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] transition-colors cursor-pointer"
              >
                <RotateCw className="w-3.5 h-3.5 text-purple-400" />
                <span>Flip Card (Front / Back)</span>
              </button>

              <button
                id="card-simulate-tap-btn"
                onClick={handleSimulateNfcTap}
                disabled={isNfcTapping}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-purple-200 bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 transition-colors cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-purple-300" />
                <span>Simulate NFC Smartphone Tap</span>
              </button>

              <button
                onClick={() => navigate(`/u/${personal.username}`)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-zinc-300 hover:text-white transition-colors cursor-pointer"
              >
                <span>Live Web View</span>
                <ExternalLink className="w-3.5 h-3.5 text-purple-400" />
              </button>
            </div>
          </div>

          {/* Right Column: Customization & Technical Specs */}
          <div className="lg:col-span-5 xl:col-span-4 space-y-6">
            {/* Card Finish / Material Theme */}
            <div className="rounded-2xl p-6 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-4">
              <h3 className="text-sm font-bold text-white tracking-tight">
                Card Finish & Style
              </h3>
              <p className="text-xs text-zinc-400">
                Choose the digital texture matching your physical Nexa metal or PVC smart card.
              </p>

              <div className="grid grid-cols-2 gap-2.5 pt-1">
                {themes.map((th) => (
                  <button
                    key={th.id}
                    onClick={() => setSelectedTheme(th.id)}
                    className={`flex items-center gap-2.5 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedTheme === th.id
                        ? 'bg-purple-950/30 border-purple-500 text-white shadow-md'
                        : 'bg-white/[0.02] border-white/[0.06] text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04]'
                    }`}
                  >
                    <span className={`w-3.5 h-3.5 rounded-full ${th.accentBg}`} />
                    <span className="text-xs font-semibold">{th.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Smart NFC Chip Technical Data */}
            <div className="rounded-2xl p-6 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white tracking-tight">
                  Hardware Specifications
                </h3>
              </div>

              <div className="divide-y divide-white/[0.05] text-xs font-mono">
                <div className="py-2 flex items-center justify-between">
                  <span className="text-zinc-500 font-sans">Chip Type</span>
                  <span className="text-zinc-300">NXP NTAG424 DNA</span>
                </div>
                <div className="py-2 flex items-center justify-between">
                  <span className="text-zinc-500 font-sans">NFC Frequency</span>
                  <span className="text-zinc-300">13.56 MHz (ISO 14443A)</span>
                </div>
                <div className="py-2 flex items-center justify-between">
                  <span className="text-zinc-500 font-sans">Public Encoding</span>
                  <span className="text-purple-300 truncate max-w-[170px]">tap.nexacreatives.site</span>
                </div>
                <div className="py-2 flex items-center justify-between">
                  <span className="text-zinc-500 font-sans">Status</span>
                  <span className="text-emerald-400 font-semibold">● Active & Paired</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};
