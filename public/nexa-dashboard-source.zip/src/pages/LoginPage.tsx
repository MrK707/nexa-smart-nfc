import React, { useState } from 'react';
import { Eye, EyeOff, User as UserIcon } from 'lucide-react';
import { useCustomer } from '../context/CustomerContext';

export const LoginPage: React.FC = () => {
  const { login, session, navigate } = useCustomer();
  const [email, setEmail] = useState('john@nexacreatives.com');
  const [password, setPassword] = useState('••••••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');

  // If already authenticated, redirect
  React.useEffect(() => {
    if (session.isAuthenticated) {
      if (session.user?.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    }
  }, [session, navigate]);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setErrorMessage('Please enter your email address');
      return;
    }

    if (email.toLowerCase().includes('admin')) {
      login(email, 'admin');
    } else {
      login(email, 'customer');
    }
  };

  const handleQuickDemo = (role: 'customer' | 'admin') => {
    if (role === 'admin') {
      setEmail('admin@nexacreatives.com');
      login('admin@nexacreatives.com', 'admin');
    } else {
      setEmail('john@nexacreatives.com');
      login('john@nexacreatives.com', 'customer');
    }
  };

  return (
    <div className="min-h-screen bg-[#1c1c1f] flex flex-col items-center justify-center p-4 sm:p-6 antialiased">
      {/* Floating Card Matching IMG_8124.png */}
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl shadow-black/60 overflow-hidden flex flex-col md:flex-row border border-white/20">
        
        {/* LEFT PANEL: Deep Black with Cyber Mascot (faithful to reference image) */}
        <div className="md:w-1/2 bg-[#0c0c0e] flex flex-col items-center justify-center p-8 sm:p-12 relative min-h-[300px] md:min-h-[580px] overflow-hidden">
          {/* Subtle floor shadow */}
          <div className="absolute bottom-12 w-48 h-8 bg-black/60 rounded-full blur-xl pointer-events-none" />

          {/* Cyber Visor / Mascot Icon SVG matching the reference design */}
          <div className="relative z-10 flex flex-col items-center">
            <svg 
              className="w-36 h-36 sm:w-44 sm:h-44 text-white drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]" 
              viewBox="0 0 200 200" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Antenna on left top */}
              <line x1="45" y1="40" x2="65" y2="70" stroke="white" strokeWidth="6" strokeLinecap="round" />
              <circle cx="43" cy="38" r="5" fill="white" />
              
              {/* Left ear latch */}
              <rect x="18" y="85" width="10" height="28" rx="4" fill="white" />
              {/* Right ear latch */}
              <rect x="172" y="85" width="10" height="28" rx="4" fill="white" />

              {/* Main Outer Geometric Head Shield */}
              <path 
                d="M48 68 L152 68 L170 100 L152 136 L48 136 L30 100 Z" 
                stroke="white" 
                strokeWidth="8" 
                strokeLinejoin="round" 
                fill="#121215"
              />

              {/* Inner Screen Visor Panel */}
              <path 
                d="M58 78 L142 78 L156 100 L142 124 L58 124 L44 100 Z" 
                fill="#202026" 
              />

              {/* Left Screen Mask - Cross eye "X" */}
              <path 
                d="M62 84 H102 C104 84 106 86 106 88 V114 C106 116 104 118 102 118 H62 C60 118 58 116 58 114 V88 C58 86 60 84 62 84 Z" 
                fill="#ececed" 
              />
              <path 
                d="M74 94 L86 106 M86 94 L74 106" 
                stroke="#121215" 
                strokeWidth="4" 
                strokeLinecap="round" 
              />

              {/* Right Screen sensor square */}
              <rect x="122" y="96" width="10" height="10" rx="2" fill="#ececed" />
            </svg>
            
            {/* Ground reflection gradient */}
            <div className="w-24 h-4 bg-purple-500/10 rounded-full blur-md mt-2" />
          </div>

          {/* Subtext */}
          <div className="absolute bottom-6 text-center">
            <span className="text-[11px] font-mono tracking-widest text-zinc-500 uppercase">
              NEXA CREATIVES IDENTITY ENGINE
            </span>
          </div>
        </div>

        {/* RIGHT PANEL: Clean Crisp White Form (matching reference image) */}
        <div className="md:w-1/2 bg-[#fafafa] text-zinc-800 p-8 sm:p-12 flex flex-col justify-between">
          <div className="space-y-6">
            {/* Top avatar icon */}
            <div className="flex justify-center">
              <div className="w-12 h-12 rounded-full bg-[#f0f0f2] flex items-center justify-center text-zinc-500 shadow-xs">
                <UserIcon className="w-6 h-6 text-zinc-600" />
              </div>
            </div>

            {/* Heading & Subtitle */}
            <div className="text-center space-y-1">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#111113] tracking-tight">
                Welcome back!
              </h2>
              <p className="text-xs sm:text-sm text-zinc-500">
                Enter your login details
              </p>
            </div>

            {errorMessage && (
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium text-center">
                {errorMessage}
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Email Field */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-700">
                  Email
                </label>
                <input
                  type="email"
                  id="login-email-input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  required
                  className="w-full px-4 py-3 rounded-xl bg-[#eeeeef] border border-transparent focus:border-zinc-400 focus:bg-white focus:outline-hidden text-sm text-zinc-900 transition-colors shadow-inner"
                />
              </div>

              {/* Password Field with Eye toggle */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-700">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="login-password-input"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-[#eeeeef] border border-transparent focus:border-zinc-400 focus:bg-white focus:outline-hidden text-sm text-zinc-900 transition-colors shadow-inner pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(prev => !prev)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 cursor-pointer p-1"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember me & Forgot Password */}
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 text-zinc-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 accent-black rounded cursor-pointer"
                  />
                  <span className="font-medium">Remember me</span>
                </label>

                <button
                  type="button"
                  onClick={() => alert('Password reset link sent to registered email.')}
                  className="text-zinc-600 hover:text-black font-medium transition-colors cursor-pointer"
                >
                  Forgot password?
                </button>
              </div>

              {/* Log In Pill Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  id="login-submit-btn"
                  className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-b from-[#242426] to-[#0c0c0e] hover:from-[#1b1b1c] hover:to-black text-white text-sm font-bold shadow-lg shadow-black/20 hover:shadow-black/40 active:scale-[0.99] transition-all cursor-pointer"
                >
                  Log in
                </button>
              </div>
            </form>

            {/* Divider Or */}
            <div className="relative flex items-center justify-center my-4">
              <div className="w-full border-t border-zinc-200" />
              <span className="absolute px-3 bg-[#fafafa] text-xs text-zinc-400 font-medium">
                Or
              </span>
            </div>

            {/* Social Logins */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('customer')}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white border border-zinc-200 hover:bg-zinc-50 text-xs font-semibold text-zinc-700 shadow-xs transition-colors cursor-pointer"
              >
                <span className="font-bold text-red-500">G</span>
                <span>Google</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('customer')}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white border border-zinc-200 hover:bg-zinc-50 text-xs font-semibold text-zinc-700 shadow-xs transition-colors cursor-pointer"
              >
                <span></span>
                <span>Apple</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('customer')}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white border border-zinc-200 hover:bg-zinc-50 text-xs font-semibold text-zinc-700 shadow-xs transition-colors cursor-pointer"
              >
                <span className="font-bold font-mono">𝕏</span>
                <span>Twitter</span>
              </button>
            </div>

            {/* Quick 1-Click Access for Seamless Testing */}
            <div className="pt-2 text-center">
              <span className="text-[11px] text-zinc-400 block mb-1">Instant Demo Switch:</span>
              <div className="inline-flex gap-2">
                <button
                  type="button"
                  onClick={() => handleQuickDemo('customer')}
                  className="px-2.5 py-1 rounded-lg bg-purple-50 text-purple-700 border border-purple-200 text-[11px] font-semibold hover:bg-purple-100 transition-colors cursor-pointer"
                >
                  Customer (John) →
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemo('admin')}
                  className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 text-[11px] font-semibold hover:bg-amber-100 transition-colors cursor-pointer"
                >
                  Admin Mode →
                </button>
              </div>
            </div>
          </div>

          {/* Footer Signup Link */}
          <div className="pt-6 text-center text-xs text-zinc-500">
            <span>Don't have an account? </span>
            <button
              onClick={() => handleQuickDemo('customer')}
              className="font-bold text-zinc-900 hover:underline cursor-pointer"
            >
              Sign Up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
