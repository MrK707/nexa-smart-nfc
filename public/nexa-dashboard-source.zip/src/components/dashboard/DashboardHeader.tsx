import React, { useState } from 'react';
import { Bell, Sparkles, ExternalLink } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';
import { NotificationDrawer } from './NotificationDrawer';

export const DashboardHeader: React.FC = () => {
  const { profile, unreadNotificationCount, navigate } = useCustomer();
  const [showNotifications, setShowNotifications] = useState(false);

  const firstName = profile.personal.full_name?.split(' ')[0] || 'Customer';

  return (
    <header 
      id="dashboard-header" 
      className="relative flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 pt-2 border-b border-white/[0.06] transition-all"
    >
      {/* Left Greeting & Heading */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-purple-400">
            Welcome back
          </span>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-purple-500/10 text-purple-300 border border-purple-500/20">
            <Sparkles className="w-2.5 h-2.5" />
            NFC Smart Card Connected
          </span>
        </div>
        
        <h1 
          id="dashboard-user-greeting"
          className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight flex items-center gap-2"
        >
          <span>Hello, {firstName}</span>
          <span className="inline-block animate-wave origin-bottom-right">👋</span>
        </h1>
        
        <p className="text-sm text-zinc-400 font-normal">
          Manage your digital business identity from one place.
        </p>
      </div>

      {/* Right Controls: Notification & Profile with online indicator */}
      <div className="flex items-center gap-3 self-end md:self-center">
        {/* Quick NFC view pill */}
        <button
          onClick={() => navigate(`/u/${profile.personal.username}`)}
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-zinc-300 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] hover:border-purple-500/30 transition-all cursor-pointer"
          title="Open live public profile"
        >
          <span>View Public</span>
          <ExternalLink className="w-3 h-3 text-purple-400" />
        </button>

        {/* Notifications Icon Button */}
        <div className="relative">
          <button
            id="header-notification-button"
            onClick={() => setShowNotifications(prev => !prev)}
            aria-label="View notifications"
            className="relative p-2.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.08] hover:border-purple-500/30 text-zinc-300 hover:text-white transition-all cursor-pointer"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-purple-500 ring-2 ring-[#0c0b11] animate-ping" />
            )}
            {unreadNotificationCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-purple-500 ring-2 ring-[#0c0b11]" />
            )}
          </button>

          <NotificationDrawer 
            isOpen={showNotifications} 
            onClose={() => setShowNotifications(false)} 
          />
        </div>

        {/* Profile Avatar with small online/active indicator */}
        <div 
          onClick={() => navigate('/dashboard/profile')}
          className="relative cursor-pointer group p-0.5 rounded-full"
          title="Edit your profile"
        >
          <div className="relative w-10 h-10 rounded-full p-[1.5px] bg-gradient-to-tr from-purple-600 via-indigo-500 to-purple-400 group-hover:scale-105 transition-transform duration-200">
            <img
              src={profile.personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
              alt={profile.personal.full_name}
              className="w-full h-full rounded-full object-cover bg-zinc-900"
            />
          </div>
          {/* Active online pulse indicator */}
          <span 
            className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#09090b] shadow-sm shadow-emerald-500/50" 
            title="Digital Card Online"
          />
        </div>
      </div>
    </header>
  );
};
