import React from 'react';
import { 
  History, 
  Radio, 
  Share2, 
  UserCheck, 
  Download, 
  Lock, 
  ArrowUpRight 
} from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';
import { ActivityItem } from '../../types';

export const RecentActivity: React.FC = () => {
  const { activities, navigate } = useCustomer();

  const getActivityIcon = (type: ActivityItem['type']) => {
    switch (type) {
      case 'card_viewed':
        return <Radio className="w-3.5 h-3.5 text-purple-400" />;
      case 'vcard_saved':
        return <Download className="w-3.5 h-3.5 text-emerald-400" />;
      case 'link_shared':
        return <Share2 className="w-3.5 h-3.5 text-blue-400" />;
      case 'profile_updated':
        return <UserCheck className="w-3.5 h-3.5 text-amber-400" />;
      case 'card_locked':
        return <Lock className="w-3.5 h-3.5 text-rose-400" />;
      default:
        return <History className="w-3.5 h-3.5 text-zinc-400" />;
    }
  };

  return (
    <section 
      id="recent-activity-section"
      className="rounded-2xl p-6 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] hover:border-purple-500/25 shadow-xl shadow-black/40 transition-all duration-300"
    >
      <div className="flex items-center justify-between pb-4 border-b border-white/[0.06]">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-purple-400" />
          <h3 className="text-base font-bold text-white tracking-tight">
            Recent Activity
          </h3>
        </div>
        <span className="text-xs text-zinc-500 font-mono">
          Event Log
        </span>
      </div>

      <div className="mt-4">
        {activities.length === 0 ? (
          <div className="py-8 text-center">
            <p className="text-sm text-zinc-400">No recent activity yet.</p>
            <p className="text-xs text-zinc-600 mt-1">Actions on your smart card and profile will appear here.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activities.slice(0, 4).map((item, idx) => (
              <div key={item.id} className="relative flex items-start gap-3 group">
                {/* Timeline connector line */}
                {idx !== Math.min(activities.length, 4) - 1 && (
                  <div className="absolute left-[15px] top-7 bottom-0 w-[1px] bg-white/[0.06] -z-0" />
                )}

                <div className="relative z-10 p-2 rounded-xl bg-white/[0.04] border border-white/[0.06] group-hover:border-purple-500/30 group-hover:bg-purple-950/20 transition-colors shrink-0">
                  {getActivityIcon(item.type)}
                </div>

                <div className="flex-1 min-w-0 pt-0.5">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-semibold text-zinc-200 group-hover:text-white transition-colors truncate">
                      {item.title}
                    </p>
                    <span className="text-[10px] text-zinc-500 shrink-0 font-medium">
                      {item.timestamp}
                    </span>
                  </div>
                  {item.detail && (
                    <p className="text-[11px] text-zinc-400 mt-0.5 leading-relaxed truncate">
                      {item.detail}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
