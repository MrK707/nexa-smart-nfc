import React from 'react';
import { UserPen, Eye, ShieldCheck, Sparkles, Building2 } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const ProfileHero: React.FC = () => {
  const { profile, navigate } = useCustomer();
  const { personal, business, card } = profile;

  const isCardActive = card.card_status === 'active';

  return (
    <section 
      id="profile-hero-card"
      className="group relative rounded-2xl sm:rounded-3xl p-6 sm:p-8 bg-[#121118]/85 backdrop-blur-xl border border-white/[0.08] hover:border-purple-500/30 shadow-xl shadow-black/40 hover:shadow-2xl hover:shadow-purple-950/20 hover:-translate-y-0.5 transition-all duration-300 overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-purple-600/10 via-indigo-600/5 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-72 h-72 bg-purple-950/20 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6 sm:gap-8">
        {/* Left Side: Avatar with subtle animated ring + Name & Bio */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 sm:gap-6">
          {/* Avatar with subtle animated glow/ring */}
          <div className="relative shrink-0">
            {/* Animated subtle outer halo ring */}
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-purple-600 via-indigo-500 to-purple-400 opacity-60 blur-xs animate-[spin_8s_linear_infinite]" />
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full p-[2px] bg-[#0c0b11]">
              <img
                src={personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                alt={personal.full_name}
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            {/* Active smart badge icon */}
            <div 
              className="absolute -bottom-1 -right-1 p-1 rounded-full bg-[#0c0b11] border border-white/10 shadow" 
              title="Verified NFC Identity"
            >
              <ShieldCheck className="w-4 h-4 text-purple-400" />
            </div>
          </div>

          {/* Details */}
          <div className="space-y-1.5 min-w-0">
            {/* Active Status Badge */}
            <div className="flex flex-wrap items-center gap-2">
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${
                isCardActive 
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${isCardActive ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`}></span>
                {isCardActive ? 'Digital Card Active' : 'Digital Card Inactive'}
              </span>

              <span className="text-xs text-zinc-500 font-mono">
                @{personal.username}
              </span>
            </div>

            {/* Name */}
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              {personal.full_name || 'Your Full Name'}
            </h2>

            {/* Title & Company */}
            <div className="flex flex-wrap items-center gap-x-2 text-sm text-zinc-300 font-medium">
              <span className="text-purple-300 font-semibold">{personal.job_title || 'Position Title'}</span>
              {business.company_name && (
                <>
                  <span className="text-zinc-600">•</span>
                  <span className="inline-flex items-center gap-1 text-zinc-400">
                    <Building2 className="w-3.5 h-3.5 text-zinc-500" />
                    {business.company_name}
                  </span>
                </>
              )}
            </div>

            {/* Short Bio snippet if available */}
            {business.bio && (
              <p className="text-xs text-zinc-400 max-w-xl line-clamp-2 leading-relaxed pt-1">
                {business.bio}
              </p>
            )}
          </div>
        </div>

        {/* Right Side: Action Buttons */}
        <div className="flex flex-row sm:flex-col lg:flex-row items-center gap-3 shrink-0">
          <button
            id="hero-edit-profile-btn"
            onClick={() => navigate('/dashboard/profile')}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-medium text-sm text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-900/30 hover:shadow-purple-900/50 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] transition-all cursor-pointer"
          >
            <UserPen className="w-4 h-4" />
            <span>Edit Profile</span>
          </button>

          <button
            id="hero-view-card-btn"
            onClick={() => navigate('/dashboard/card')}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-medium text-sm text-zinc-200 bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.1] hover:border-purple-500/30 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Eye className="w-4 h-4 text-purple-400" />
            <span>View My Card</span>
          </button>
        </div>
      </div>
    </section>
  );
};
