import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { 
  X, 
  Copy, 
  Check, 
  Share2, 
  MessageSquare, 
  Download, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const ShareModal: React.FC = () => {
  const { profile, isShareModalOpen, setShareModalOpen, recordCustomActivity } = useCustomer();
  const { personal, card } = profile;

  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  const publicUrl = `https://tap.nexacreatives.site/u/${personal.username}`;

  useEffect(() => {
    if (isShareModalOpen && personal.username) {
      QRCode.toDataURL(publicUrl, {
        width: 320,
        margin: 2,
        color: {
          dark: '#0c0b11',
          light: '#ffffff',
        },
      })
        .then((url) => setQrDataUrl(url))
        .catch((err) => console.error('Failed to generate QR', err));
    }
  }, [isShareModalOpen, personal.username, publicUrl]);

  if (!isShareModalOpen) return null;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(publicUrl);
      setCopied(true);
      recordCustomActivity('link_shared', 'Public profile link copied to clipboard', publicUrl);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${personal.full_name} - Nexa Smart Digital Card`,
          text: `Connect with ${personal.full_name} (${personal.job_title} at ${profile.business.company_name}):`,
          url: publicUrl,
        });
        recordCustomActivity('link_shared', 'Shared via Native System Share', publicUrl);
      } catch (err) {
        // User cancelled or not supported
        console.log('Share dismissed or cancelled', err);
      }
    } else {
      handleCopyLink();
      setShareFeedback('Link copied! Paste anywhere to share.');
      setTimeout(() => setShareFeedback(null), 3000);
    }
  };

  const handleWhatsAppShare = () => {
    const message = encodeURIComponent(
      `Hi! Here is my Nexa Smart NFC digital business card:\n${personal.full_name} | ${personal.job_title}\n${publicUrl}`
    );
    recordCustomActivity('link_shared', 'Shared card to WhatsApp', publicUrl);
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  const handleDownloadQr = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = `${personal.username || 'nexa'}-smart-qr.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    recordCustomActivity('qr_scanned', 'Smart Card QR Code image downloaded');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
        onClick={() => setShareModalOpen(false)}
      />

      {/* Modal Dialog */}
      <div 
        id="share-card-modal"
        className="relative z-10 w-full max-w-md bg-[#121118] border border-white/[0.1] rounded-3xl p-6 sm:p-7 shadow-2xl shadow-purple-950/40 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          onClick={() => setShareModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/[0.08] transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header & Profile */}
        <div className="text-center space-y-3 pt-1">
          <div className="relative inline-block mx-auto">
            <div className="w-20 h-20 rounded-full p-[2px] bg-gradient-to-tr from-purple-500 via-indigo-500 to-purple-400">
              <img
                src={personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                alt={personal.full_name}
                className="w-full h-full rounded-full object-cover bg-zinc-900"
              />
            </div>
            <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#121118]" />
          </div>

          <div>
            <h3 className="text-xl font-bold text-white tracking-tight">
              {personal.full_name}
            </h3>
            <p className="text-xs text-purple-300 font-medium">
              {personal.job_title} {profile.business.company_name && `• ${profile.business.company_name}`}
            </p>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/40 border border-purple-500/20 text-xs text-purple-200 font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
            <span>NFC Verified Card</span>
          </div>
        </div>

        {/* Dynamic High-Res QR Code Card */}
        <div className="mt-6 flex flex-col items-center">
          <div className="p-4 bg-white rounded-2xl shadow-xl shadow-black/50 border border-white/20 flex flex-col items-center">
            {qrDataUrl ? (
              <img 
                src={qrDataUrl} 
                alt={`QR code for ${personal.full_name}`}
                className="w-48 h-48 sm:w-52 sm:h-52 object-contain"
              />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center text-zinc-500 text-xs">
                Generating QR...
              </div>
            )}
            <p className="text-[10px] font-mono tracking-wider text-zinc-500 uppercase mt-2">
              Scan with any camera or NFC
            </p>
          </div>
        </div>

        {/* Public Profile URL Box */}
        <div className="mt-5 p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.08] flex items-center justify-between gap-2">
          <span className="text-xs font-mono text-zinc-300 truncate pl-1">
            {publicUrl}
          </span>
          <button
            onClick={handleCopyLink}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/30 transition-all cursor-pointer shrink-0"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-purple-300" />
                <span>Copy Link</span>
              </>
            )}
          </button>
        </div>

        {shareFeedback && (
          <p className="text-center text-xs text-emerald-400 mt-2 font-medium">
            {shareFeedback}
          </p>
        )}

        {/* 4 Action Buttons Grid */}
        <div className="grid grid-cols-2 gap-2.5 mt-5">
          <button
            id="share-modal-copy-btn"
            onClick={handleCopyLink}
            className="flex items-center justify-center gap-2 p-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-zinc-200 text-xs font-semibold transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-purple-400" />}
            <span>{copied ? 'Link Copied' : 'Copy Link'}</span>
          </button>

          <button
            id="share-modal-native-btn"
            onClick={handleNativeShare}
            className="flex items-center justify-center gap-2 p-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-200 text-xs font-semibold transition-colors cursor-pointer"
          >
            <Share2 className="w-4 h-4 text-purple-300" />
            <span>Share</span>
          </button>

          <button
            id="share-modal-whatsapp-btn"
            onClick={handleWhatsAppShare}
            className="flex items-center justify-center gap-2 p-3 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-300 text-xs font-semibold transition-colors cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <span>WhatsApp</span>
          </button>

          <button
            id="share-modal-download-qr-btn"
            onClick={handleDownloadQr}
            className="flex items-center justify-center gap-2 p-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-zinc-200 text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-blue-400" />
            <span>Download QR</span>
          </button>
        </div>
      </div>
    </div>
  );
};
