import React from 'react';
import { Sidebar } from './Sidebar';
import { MobileNavigation } from './MobileNavigation';
import { ShareModal } from './ShareModal';
import { useCustomer } from '../../context/CustomerContext';
import { Radio, Share2, ExternalLink } from 'lucide-react';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { profile, navigate, setShareModalOpen } = useCustomer();

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] flex flex-col md:flex-row antialiased overflow-x-hidden">
      {/* Desktop & Tablet Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 pb-20 md:pb-8">
        {/* Compact Mobile Top Header */}
        <header className="md:hidden sticky top-0 z-30 bg-[#0c0b11]/90 backdrop-blur-xl border-b border-white/[0.08] px-4 py-3 flex items-center justify-between">
          <div 
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 p-[1px]">
              <div className="w-full h-full bg-[#0d0c14] rounded-[7px] flex items-center justify-center font-bold text-white text-sm">
                N
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white text-sm tracking-tight">NEXA</span>
              <span className="text-[9px] font-bold text-purple-400 uppercase bg-purple-950/60 px-1 py-0.2 rounded border border-purple-500/20">
                NFC
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShareModalOpen(true)}
              className="p-2 rounded-lg bg-white/[0.04] text-zinc-300 hover:text-white border border-white/[0.06] cursor-pointer"
              title="Share Card"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <div 
              onClick={() => navigate('/dashboard/profile')}
              className="relative cursor-pointer"
            >
              <img
                src={profile.personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                alt={profile.personal.full_name}
                className="w-8 h-8 rounded-full object-cover border border-purple-500/40"
              />
              <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-[#0c0b11]" />
            </div>
          </div>
        </header>

        {/* Page Content View */}
        <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Fixed Navigation */}
      <MobileNavigation />

      {/* Global Share Modal */}
      <ShareModal />
    </div>
  );
};
