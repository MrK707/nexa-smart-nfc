import React from 'react';
import { UserPen, CreditCard, Share2, Settings, ArrowUpRight } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const QuickActions: React.FC = () => {
  const { navigate, setShareModalOpen } = useCustomer();

  const actions = [
    {
      id: 'action-edit-profile',
      title: 'Edit Profile',
      description: 'Update your personal and business information.',
      icon: UserPen,
      iconColor: 'text-purple-400 group-hover:text-purple-300',
      iconBg: 'bg-purple-500/10 group-hover:bg-purple-500/20 border-purple-500/20',
      onClick: () => navigate('/dashboard/profile'),
    },
    {
      id: 'action-my-card',
      title: 'My Digital Card',
      description: 'Preview your live NFC business card.',
      icon: CreditCard,
      iconColor: 'text-indigo-400 group-hover:text-indigo-300',
      iconBg: 'bg-indigo-500/10 group-hover:bg-indigo-500/20 border-indigo-500/20',
      onClick: () => navigate('/dashboard/card'),
    },
    {
      id: 'action-share-card',
      title: 'Share Card',
      description: 'Share your card using QR, link, WhatsApp or native sharing.',
      icon: Share2,
      iconColor: 'text-emerald-400 group-hover:text-emerald-300',
      iconBg: 'bg-emerald-500/10 group-hover:bg-emerald-500/20 border-emerald-500/20',
      onClick: () => setShareModalOpen(true),
    },
    {
      id: 'action-settings',
      title: 'Settings',
      description: 'Manage account preferences.',
      icon: Settings,
      iconColor: 'text-zinc-400 group-hover:text-zinc-200',
      iconBg: 'bg-white/[0.05] group-hover:bg-white/[0.08] border-white/[0.08]',
      onClick: () => navigate('/dashboard/settings'),
    },
  ];

  return (
    <section id="quick-actions-section" className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-white tracking-tight">
          Quick Actions
        </h3>
        <span className="text-xs text-zinc-500 font-medium">
          Instant Shortcuts
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {actions.map((act) => {
          const Icon = act.icon;
          return (
            <button
              key={act.id}
              id={act.id}
              onClick={act.onClick}
              className="group relative text-left p-5 rounded-2xl bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] hover:border-purple-500/35 hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-950/20 transition-all duration-200 cursor-pointer overflow-hidden flex flex-col justify-between"
            >
              {/* Subtle top corner ambient glow on hover */}
              <div className="absolute top-0 right-0 w-24 h-24 bg-purple-600/10 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-2.5 rounded-xl border transition-all duration-200 group-hover:scale-110 ${act.iconBg}`}>
                    <Icon className={`w-5 h-5 transition-colors ${act.iconColor}`} />
                  </div>
                  <div className="p-1 rounded-lg text-zinc-600 group-hover:text-purple-300 transition-colors">
                    <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </div>
                </div>

                <h4 className="text-sm font-bold text-white tracking-tight group-hover:text-purple-200 transition-colors">
                  {act.title}
                </h4>
                <p className="text-xs text-zinc-400 mt-1.5 leading-relaxed">
                  {act.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-white/[0.04] flex items-center gap-1.5 text-[11px] font-semibold text-zinc-500 group-hover:text-purple-400 transition-colors">
                <span>Open module</span>
                <span className="text-xs">→</span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};
