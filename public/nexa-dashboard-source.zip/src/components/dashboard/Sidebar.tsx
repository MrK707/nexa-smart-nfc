import React from 'react';
import { 
  LayoutDashboard, 
  UserPen, 
  CreditCard, 
  Share2, 
  Settings, 
  LogOut, 
  ExternalLink, 
  Radio, 
  ChevronRight,
  ShieldCheck,
  Download
} from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

interface SidebarProps {
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isCollapsed = false }) => {
  const { profile, currentRoute, navigate, logout, session } = useCustomer();

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      path: '/dashboard',
    },
    {
      id: 'profile',
      label: 'Edit Profile',
      icon: UserPen,
      path: '/dashboard/profile',
    },
    {
      id: 'card',
      label: 'My Digital Card',
      icon: CreditCard,
      path: '/dashboard/card',
    },
    {
      id: 'share',
      label: 'Share Card',
      icon: Share2,
      path: '/dashboard/share',
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      path: '/dashboard/settings',
    },
  ];

  const handleNav = (path: string) => {
    navigate(path);
  };

  return (
    <aside 
      id="desktop-sidebar"
      className="hidden md:flex flex-col w-64 lg:w-72 bg-[#0c0b11] border-r border-white/[0.07] h-screen sticky top-0 z-30 select-none"
    >
      {/* Brand Header */}
      <div className="p-6 pb-4 border-b border-white/[0.05]">
        <div 
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-3 cursor-pointer group"
          id="sidebar-brand-logo"
        >
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-purple-400 p-[1px] shadow-lg shadow-purple-900/30 group-hover:shadow-purple-900/50 transition-all duration-300">
            <div className="w-full h-full bg-[#0d0c14] rounded-[11px] flex items-center justify-center">
              <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-br from-white via-purple-200 to-purple-400 text-lg tracking-wider">
                N
              </span>
            </div>
            {/* Ambient signal dot */}
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#0c0b11] animate-pulse"></span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold tracking-tight text-white text-base">NEXA</span>
              <span className="text-[10px] font-semibold tracking-widest text-purple-400 uppercase bg-purple-950/60 px-1.5 py-0.5 rounded border border-purple-500/20">
                NFC
              </span>
            </div>
            <p className="text-[11px] text-zinc-500 font-medium tracking-wide">CREATIVES PLATFORM</p>
          </div>
        </div>
      </div>

      {/* Navigation Links */}
      <div className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
          Main Navigation
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentRoute === item.path;

          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => handleNav(item.path)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all duration-200 group text-left cursor-pointer ${
                isActive
                  ? 'bg-purple-600/15 text-purple-200 border border-purple-500/30 shadow-sm shadow-purple-950/40'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-1.5 rounded-lg transition-colors ${
                  isActive ? 'bg-purple-600/30 text-purple-300' : 'text-zinc-500 group-hover:text-purple-400'
                }`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span>{item.label}</span>
              </div>
              {isActive ? (
                <div className="w-1.5 h-1.5 rounded-full bg-purple-400 shadow-sm shadow-purple-400"></div>
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-zinc-600 opacity-0 group-hover:opacity-100 transition-opacity" />
              )}
            </button>
          );
        })}

        {/* Public Profile quick shortcut */}
        <div className="pt-4">
          <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
            Public Card
          </div>
          <button
            id="nav-item-view-public-url"
            onClick={() => navigate(`/u/${profile.personal.username}`)}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-xs text-zinc-400 hover:text-white bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.05] hover:border-purple-500/20 transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 truncate">
              <Radio className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="truncate">/u/{profile.personal.username}</span>
            </div>
            <ExternalLink className="w-3 h-3 text-zinc-500 group-hover:text-purple-300 shrink-0" />
          </button>
        </div>

        {/* Admin Link if role is admin */}
        {session.user?.role === 'admin' && (
          <div className="pt-2">
            <button
              id="nav-item-admin-console"
              onClick={() => navigate('/admin')}
              className="w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-xs font-medium text-amber-400/90 bg-amber-500/10 border border-amber-500/20 hover:bg-amber-500/20 cursor-pointer transition-colors"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Admin Management</span>
            </button>
          </div>
        )}

        {/* Download Project Source ZIP */}
        <div className="pt-4">
          <a
            id="nav-item-download-zip"
            href="/nexa-dashboard-source.zip"
            download="nexa-dashboard-source.zip"
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-xs text-purple-200 hover:text-white bg-purple-950/40 hover:bg-purple-900/40 border border-purple-500/30 transition-all cursor-pointer group shadow-xs"
          >
            <div className="flex items-center gap-2.5 truncate">
              <Download className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform shrink-0" />
              <span className="truncate font-semibold">Download Project ZIP</span>
            </div>
            <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">
              .zip
            </span>
          </a>
        </div>
      </div>

      {/* User profile & Logout */}
      <div className="p-4 border-t border-white/[0.06] bg-[#09080e]/60">
        <div className="flex items-center justify-between p-2 rounded-xl hover:bg-white/[0.03] transition-colors">
          <div 
            onClick={() => navigate('/dashboard/profile')}
            className="flex items-center gap-3 cursor-pointer min-w-0 flex-1 mr-2"
            title="Edit profile"
          >
            <div className="relative shrink-0">
              <img
                src={profile.personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                alt={profile.personal.full_name}
                className="w-9 h-9 rounded-full object-cover border border-purple-500/30"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#0c0b11]"></span>
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-white truncate">{profile.personal.full_name}</p>
              <p className="text-[11px] text-zinc-500 truncate">@{profile.personal.username}</p>
            </div>
          </div>
          
          <button
            id="sidebar-logout-btn"
            onClick={logout}
            title="Sign out of customer account"
            className="p-2 text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
