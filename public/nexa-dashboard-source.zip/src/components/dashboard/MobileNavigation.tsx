import React from 'react';
import { Home, User, CreditCard, Settings } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const MobileNavigation: React.FC = () => {
  const { currentRoute, navigate } = useCustomer();

  const navItems = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      path: '/dashboard',
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: User,
      path: '/dashboard/profile',
    },
    {
      id: 'card',
      label: 'Card',
      icon: CreditCard,
      path: '/dashboard/card',
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      path: '/dashboard/settings',
    },
  ];

  return (
    <nav
      id="mobile-bottom-navigation"
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0c0b11]/95 backdrop-blur-xl border-t border-white/[0.08] px-4 py-2"
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentRoute === item.path;

          return (
            <button
              key={item.id}
              id={`mobile-nav-${item.id}`}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center py-1.5 px-3 rounded-xl transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'text-purple-300'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform duration-150 ${isActive ? 'scale-110 text-purple-400' : ''}`} />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-purple-400 rounded-full shadow-sm shadow-purple-400"></span>
                )}
              </div>
              <span className={`text-[10px] mt-1 font-medium ${isActive ? 'text-purple-200 font-semibold' : ''}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
