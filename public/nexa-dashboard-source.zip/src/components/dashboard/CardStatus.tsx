import React from 'react';
import { Radio, Eye, Lock, ShieldCheck } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const CardStatus: React.FC = () => {
  const { profile, navigate } = useCustomer();
  const { card } = profile;

  const isActive = card.card_status === 'active';

  return (
    <div 
      id="smart-card-status-card"
      className="rounded-2xl p-6 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] hover:border-purple-500/25 shadow-xl shadow-black/40 transition-all duration-300 flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-purple-400 animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-400">
              Hardware Link
            </span>
          </div>

          {/* Active status pill */}
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
            isActive 
              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
              : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-400 animate-ping' : 'bg-rose-400'}`}></span>
            {isActive ? '● Active' : '● Locked'}
          </span>
        </div>

        <h3 className="text-lg font-bold text-white tracking-tight mt-2">
          Smart Card Status
        </h3>

        <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
          {isActive
            ? 'Your NFC digital card is connected and ready to share.'
            : 'Your card is currently locked. Taps will not broadcast contact data.'}
        </p>

        {card.nfc_uid && (
          <div className="mt-3 py-1.5 px-2.5 rounded-lg bg-white/[0.03] border border-white/[0.05] flex items-center justify-between text-[11px] font-mono text-zinc-400">
            <span className="text-zinc-500 font-sans">Chip UID:</span>
            <span className="text-purple-300 font-medium">{card.nfc_uid}</span>
          </div>
        )}
      </div>

      <div className="mt-5 pt-4 border-t border-white/[0.06] flex items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 text-xs text-zinc-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Encrypted Tag</span>
        </div>

        <button
          id="card-status-view-card-btn"
          onClick={() => navigate('/dashboard/card')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-zinc-200 bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.08] hover:border-purple-500/30 transition-all cursor-pointer"
        >
          <Eye className="w-3.5 h-3.5 text-purple-400" />
          <span>View Card</span>
        </button>
      </div>
    </div>
  );
};
