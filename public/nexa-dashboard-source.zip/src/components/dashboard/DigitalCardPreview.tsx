import React from 'react';
import { 
  Radio, 
  ExternalLink, 
  Phone, 
  Mail, 
  Globe, 
  MessageSquare, 
  Instagram, 
  Linkedin, 
  Facebook, 
  Share2, 
  QrCode,
  ShieldCheck
} from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const DigitalCardPreview: React.FC = () => {
  const { profile, navigate, setShareModalOpen } = useCustomer();
  const { personal, business, contact, social, card } = profile;

  return (
    <div 
      id="digital-card-preview-section"
      className="rounded-2xl p-6 sm:p-7 bg-[#121118]/85 backdrop-blur-xl border border-white/[0.08] hover:border-purple-500/25 shadow-xl shadow-black/40 transition-all duration-300"
    >
      {/* Top Header with LIVE PREVIEW badge */}
      <div className="flex items-center justify-between pb-5 border-b border-white/[0.06]">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-[11px] font-bold tracking-widest text-emerald-400 uppercase bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-500/20">
            LIVE PREVIEW
          </span>
          <span className="text-xs text-zinc-400 hidden sm:inline">
            Smart NFC Digital Business Card
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShareModalOpen(true)}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/[0.06] transition-colors cursor-pointer"
            title="Quick Share Card"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            id="preview-view-public-profile-btn"
            onClick={() => navigate(`/u/${personal.username}`)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-purple-300 hover:text-white bg-purple-600/15 hover:bg-purple-600/25 border border-purple-500/30 transition-all cursor-pointer"
          >
            <span>View Public Profile</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Realistic Smart Card Shell */}
      <div className="mt-6 flex justify-center">
        <div 
          id="nfc-card-card-canvas"
          className="relative w-full max-w-md rounded-2xl p-6 sm:p-7 bg-gradient-to-br from-[#1b172a] via-[#100e18] to-[#0a0910] border border-white/[0.12] shadow-2xl shadow-purple-950/40 overflow-hidden group"
        >
          {/* Subtle NFC waves watermark */}
          <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-60">
            <Radio className="w-4 h-4 text-purple-400" />
            <span className="text-[10px] font-mono tracking-widest text-purple-300 font-semibold uppercase">
              NFC
            </span>
          </div>

          {/* Background sheen effect */}
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/10 via-transparent to-white/[0.03] pointer-events-none" />

          {/* Profile Identity Top */}
          <div className="relative z-10 flex items-start gap-4">
            <div className="relative w-16 h-16 sm:w-18 sm:h-18 rounded-2xl p-[1.5px] bg-gradient-to-br from-purple-500 via-indigo-500 to-purple-800 shrink-0 shadow-lg">
              <img
                src={personal.profile_photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                alt={personal.full_name}
                className="w-full h-full rounded-[14px] object-cover bg-zinc-900"
              />
            </div>

            <div className="min-w-0 flex-1 pr-6">
              <h4 className="text-lg sm:text-xl font-bold text-white tracking-tight truncate">
                {personal.full_name || 'Customer Name'}
              </h4>
              <p className="text-xs font-semibold text-purple-300 truncate">
                {personal.job_title || 'Position Title'}
              </p>
              <p className="text-xs text-zinc-400 truncate">
                {business.company_name || 'Nexa Creatives'}
              </p>
            </div>
          </div>

          {/* Bio snippet */}
          {business.bio && (
            <p className="relative z-10 text-xs text-zinc-300/90 leading-relaxed mt-4 pt-3 border-t border-white/[0.06] line-clamp-2">
              {business.bio}
            </p>
          )}

          {/* Contact Pills Grid */}
          <div className="relative z-10 grid grid-cols-2 gap-2 mt-4 pt-2">
            {contact.phone && (
              <a
                href={`tel:${contact.phone}`}
                className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.05] text-zinc-300 text-xs transition-colors truncate"
              >
                <Phone className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span className="truncate">{contact.phone}</span>
              </a>
            )}

            {contact.whatsapp && (
              <a
                href={`https://wa.me/${contact.whatsapp.replace(/\D/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.05] text-zinc-300 text-xs transition-colors truncate"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">WhatsApp</span>
              </a>
            )}

            {contact.email && (
              <a
                href={`mailto:${contact.email}`}
                className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.05] text-zinc-300 text-xs transition-colors truncate"
              >
                <Mail className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span className="truncate">{contact.email}</span>
              </a>
            )}

            {contact.website && (
              <a
                href={contact.website}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.05] text-zinc-300 text-xs transition-colors truncate"
              >
                <Globe className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="truncate">{contact.website.replace(/^https?:\/\//, '')}</span>
              </a>
            )}
          </div>

          {/* Social Row */}
          <div className="relative z-10 flex items-center justify-between mt-5 pt-3 border-t border-white/[0.06]">
            <div className="flex items-center gap-3 text-zinc-400">
              {social.instagram && (
                <span className="hover:text-pink-400 transition-colors cursor-pointer" title={`@${social.instagram}`}>
                  <Instagram className="w-4 h-4" />
                </span>
              )}
              {social.linkedin && (
                <span className="hover:text-blue-400 transition-colors cursor-pointer" title={social.linkedin}>
                  <Linkedin className="w-4 h-4" />
                </span>
              )}
              {social.facebook && (
                <span className="hover:text-blue-500 transition-colors cursor-pointer" title={social.facebook}>
                  <Facebook className="w-4 h-4" />
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 text-[11px] font-mono text-zinc-500">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
              <span>NEXA SMART ID</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
