import React from 'react';
import { ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const OnboardingCard: React.FC = () => {
  const { completion, navigate } = useCustomer();

  // Once profile completion reaches 100%, automatically hide the onboarding card
  if (completion.percentage >= 100) {
    return null;
  }

  return (
    <div 
      id="onboarding-incomplete-card"
      className="relative rounded-2xl p-6 sm:p-7 bg-gradient-to-r from-purple-950/40 via-[#161224] to-[#12111a] border border-purple-500/30 shadow-xl shadow-purple-950/20 overflow-hidden"
    >
      {/* Background ambient flare */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-300">
              Identity Onboarding
            </span>
          </div>

          <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
            Let’s finish your digital identity
          </h3>

          <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
            Complete your profile so customers can easily connect with you via NFC tap and save your details in one click.
          </p>

          {/* Animated progress bar */}
          <div className="pt-2 flex items-center gap-3">
            <div className="flex-1 h-2 rounded-full bg-white/[0.08] overflow-hidden max-w-xs">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-indigo-400 rounded-full transition-all duration-700 ease-out"
                style={{ width: `${completion.percentage}%` }}
              />
            </div>
            <span className="text-xs font-bold text-purple-300 font-mono">
              {completion.percentage}%
            </span>
          </div>
        </div>

        <button
          id="onboarding-complete-profile-cta"
          onClick={() => navigate('/dashboard/profile')}
          className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-900/30 hover:shadow-purple-900/50 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] transition-all cursor-pointer shrink-0"
        >
          <span>Complete Profile</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
