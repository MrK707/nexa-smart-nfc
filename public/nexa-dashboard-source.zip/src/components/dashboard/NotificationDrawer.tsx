import React from 'react';
import { Bell, CheckCheck, Shield, CreditCard, Sparkles, X } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ isOpen, onClose }) => {
  const { notifications, markNotificationsRead, unreadNotificationCount } = useCustomer();

  if (!isOpen) return null;

  const getIcon = (type: string) => {
    switch (type) {
      case 'card':
        return <CreditCard className="w-4 h-4 text-purple-400" />;
      case 'security':
        return <Shield className="w-4 h-4 text-emerald-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-blue-400" />;
    }
  };

  return (
    <>
      <div 
        className="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />
      <div 
        id="notifications-panel"
        className="fixed top-16 right-4 sm:right-8 w-80 sm:w-96 max-w-[calc(100vw-2rem)] z-50 bg-[#121118] border border-white/[0.1] rounded-2xl shadow-2xl shadow-black/80 overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      >
        <div className="flex items-center justify-between p-4 border-b border-white/[0.07] bg-white/[0.02]">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-purple-400" />
            <span className="font-semibold text-sm text-white">Notifications</span>
            {unreadNotificationCount > 0 && (
              <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-purple-500 text-white">
                {unreadNotificationCount}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadNotificationCount > 0 && (
              <button
                onClick={markNotificationsRead}
                title="Mark all as read"
                className="text-[11px] text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1 cursor-pointer"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark read</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-white/[0.06] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="max-h-96 overflow-y-auto divide-y divide-white/[0.04]">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-zinc-500 text-xs">
              No notifications at this time.
            </div>
          ) : (
            notifications.map((item) => (
              <div 
                key={item.id}
                className={`p-3.5 flex items-start gap-3 transition-colors ${
                  item.read ? 'bg-transparent' : 'bg-purple-950/20'
                }`}
              >
                <div className="p-2 rounded-xl bg-white/[0.04] border border-white/[0.06] shrink-0 mt-0.5">
                  {getIcon(item.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1 mb-0.5">
                    <p className={`text-xs font-semibold truncate ${item.read ? 'text-zinc-300' : 'text-white'}`}>
                      {item.title}
                    </p>
                    <span className="text-[10px] text-zinc-500 shrink-0">{item.timestamp}</span>
                  </div>
                  <p className="text-xs text-zinc-400 leading-relaxed">{item.message}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
};
