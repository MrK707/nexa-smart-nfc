import React, { useState, useEffect } from 'react';
import { ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { useCustomer } from '../../context/CustomerContext';

export const ProfileCompletion: React.FC = () => {
  const { completion, navigate } = useCustomer();
  const [animatedValue, setAnimatedValue] = useState(0);

  // Smooth entrance animation from 0 to actual percentage
  useEffect(() => {
    const target = completion.percentage;
    const duration = 800; // ms
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // easeOutCubic
      const easeOut = 1 - Math.pow(1 - progress, 3);
      setAnimatedValue(Math.round(easeOut * target));

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [completion.percentage]);

  const radius = 32;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (animatedValue / 100) * circumference;

  return (
    <div 
      id="profile-completion-card"
      className="rounded-2xl p-6 bg-[#121118]/80 backdrop-blur-xl border border-white/[0.08] hover:border-purple-500/25 shadow-xl shadow-black/40 transition-all duration-300 flex flex-col justify-between"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-purple-400">
            Card Readiness
          </span>
          <h3 className="text-lg font-bold text-white tracking-tight mt-0.5">
            Profile Completion
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            {completion.percentage === 100
              ? 'Your NFC business card has all contact and identity fields filled!'
              : `${completion.missingFields.length} field${completion.missingFields.length > 1 ? 's' : ''} left for optimal tap conversion.`}
          </p>
        </div>

        {/* Circular Animated Progress Indicator */}
        <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 80 80">
            {/* Background ring */}
            <circle
              cx="40"
              cy="40"
              r={radius}
              stroke="rgba(255, 255, 255, 0.08)"
              strokeWidth="6"
              fill="transparent"
            />
            {/* Animated progress ring with purple gradient */}
            <circle
              cx="40"
              cy="40"
              r={radius}
              stroke="url(#purpleProgressGrad)"
              strokeWidth="6"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              style={{ transition: 'stroke-dashoffset 0.4s ease' }}
            />
            <defs>
              <linearGradient id="purpleProgressGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#c084fc" />
                <stop offset="100%" stopColor="#7928ca" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-base font-extrabold text-white tracking-tight">
              {animatedValue}%
            </span>
            <span className="text-[9px] uppercase tracking-wider text-zinc-400 font-medium">
              Done
            </span>
          </div>
        </div>
      </div>

      {/* Dynamic Status / Missing fields info */}
      <div className="mt-5 pt-4 border-t border-white/[0.06] flex items-center justify-between gap-3">
        {completion.percentage === 100 ? (
          <div className="flex items-center gap-2 text-xs text-emerald-400 font-medium">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Profile 100% complete</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-xs text-amber-400/90 font-medium truncate">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
            <span className="truncate">
              Missing: {completion.missingFields.slice(0, 2).join(', ')}
              {completion.missingFields.length > 2 && ` +${completion.missingFields.length - 2} more`}
            </span>
          </div>
        )}

        <button
          id="profile-completion-cta"
          onClick={() => navigate('/dashboard/profile')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-purple-300 hover:text-purple-200 transition-colors group cursor-pointer shrink-0"
        >
          <span>Complete your profile</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
