import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  LogIn, 
  UserPen, 
  CreditCard, 
  Share2, 
  Settings, 
  ExternalLink, 
  ShieldCheck, 
  Compass,
  ChevronDown,
  ChevronUp,
  Download
} from 'lucide-react';
import { useCustomer } from '../context/CustomerContext';

export const QuickRouteSwitcher: React.FC = () => {
  const { currentRoute, navigate, session, login, logout } = useCustomer();
  const [isExpanded, setIsExpanded] = useState(false);

  const routes = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/login', label: 'Login Page', icon: LogIn },
    { path: '/dashboard/profile', label: 'Edit Profile', icon: UserPen },
    { path: '/dashboard/card', label: 'My Digital Card', icon: CreditCard },
    { path: '/dashboard/share', label: 'Share Card', icon: Share2 },
    { path: '/dashboard/settings', label: 'Settings', icon: Settings },
    { path: '/u/johnperera', label: 'Public NFC Profile', icon: ExternalLink },
    { path: '/admin', label: 'Admin Fleet', icon: ShieldCheck },
  ];

  const handleSelectRoute = (path: string) => {
    if (path === '/login') {
      logout();
    } else {
      if (!session.isAuthenticated) {
        login('john@nexacreatives.com', path === '/admin' ? 'admin' : 'customer');
      }
      navigate(path);
    }
  };

  return (
    <div 
      id="nexa-quick-route-switcher"
      className="fixed bottom-18 md:bottom-5 right-4 z-50 flex flex-col items-end pointer-events-auto"
    >
      {/* Expanded Menu */}
      {isExpanded && (
        <div className="mb-2 w-64 bg-[#121118]/95 backdrop-blur-xl border border-white/[0.12] rounded-2xl p-2 shadow-2xl shadow-black/80 animate-in fade-in zoom-in-95 duration-200">
          <div className="px-3 py-1.5 border-b border-white/[0.06] flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase font-bold tracking-wider text-purple-400">
              Direct Route Switcher
            </span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/[0.06] text-zinc-400 font-mono">
              Live Preview
            </span>
          </div>

          <div className="py-1 space-y-0.5 max-h-72 overflow-y-auto">
            {routes.map((r) => {
              const Icon = r.icon;
              const isActive = currentRoute === r.path;
              return (
                <button
                  key={r.path}
                  onClick={() => {
                    handleSelectRoute(r.path);
                    setIsExpanded(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-purple-600/20 text-purple-200 border border-purple-500/30'
                      : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <Icon className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span className="truncate">{r.label}</span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500">{r.path}</span>
                </button>
              );
            })}
          </div>

          <div className="mt-1 pt-1.5 border-t border-white/[0.06]">
            <a
              href="/nexa-dashboard-source.zip"
              download="nexa-dashboard-source.zip"
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Project ZIP</span>
            </a>
          </div>
        </div>
      )}

      {/* Floating Toggle Pill */}
      <button
        id="quick-route-switcher-toggle"
        onClick={() => setIsExpanded(prev => !prev)}
        className="inline-flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#1b172a] hover:bg-[#251f3b] border border-purple-500/30 text-purple-200 text-xs font-semibold shadow-xl shadow-black/60 hover:shadow-purple-950/40 transition-all cursor-pointer hover:scale-105 active:scale-95"
      >
        <Compass className="w-4 h-4 text-purple-400 animate-spin-slow" />
        <span>Pages: <span className="text-white font-mono">{currentRoute}</span></span>
        {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-zinc-400" /> : <ChevronUp className="w-3.5 h-3.5 text-zinc-400" />}
      </button>
    </div>
  );
};
